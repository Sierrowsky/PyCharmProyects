global ui
global calendar
global salir
global about
global dlgAbrir
global bbdd

version = " 0.0.1rc "
